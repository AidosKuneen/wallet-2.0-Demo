# ADK Windows Wallet

Made by **Aidos Kuneen Foundation**.

A modern, ADK-only Windows desktop wallet demo built with Electron and designed as a DAG-ready desktop client.

## What this wallet is
- ADK only
- Windows-first desktop application
- Modern protocol-terminal style interface
- ADK-style address validation using `A-Z` and `9`
- Seed-to-address demo flow
- Node / DAG panel prepared for future live ADK integration

## Important demo note
This package is a **demo wallet UI**. It is designed to look and behave like an ADK desktop client, but it is **not yet a production blockchain wallet** for real funds.

The included address derivation logic is for demonstration and interface testing. Before using real funds, replace the demo derivation logic with the final ADK-compatible cryptographic wallet logic and connect it to the live ADK DAG backend.

## Requirements
- Windows 10 or Windows 11
- Node.js LTS installed
- Internet connection during the first build so Electron packages can be downloaded

## Install and run on Windows
1. Install **Node.js LTS**.
2. Unzip this package to a normal folder, for example `C:\ADK-Wallet`.
3. Double-click `build-windows.bat`.
4. Wait for the dependencies to install and the build to complete.
5. When finished, open the `release` folder.
6. Run one of these files:
   - `ADK Windows Wallet-Portable-0.2.0.exe`
   - `ADK Windows Wallet-Setup-0.2.0.exe`

## Manual build steps
Open Command Prompt in the project folder and run:

```bash
npm install
npm run dist
```

To run the wallet in development mode instead of creating the `.exe`, use:

```bash
npm install
npm start
```

## Project structure
- `main.js` — Electron main process
- `preload.js` — preload bridge
- `index.html` — wallet layout
- `styles.css` — premium ADK desktop styling
- `app.js` — wallet UI logic, validation, demo seed/address flow
- `assets/` — ADK logo and icon assets
- `build-windows.bat` — double-click Windows build script

## Branding
This build is branded as:

**Made by Aidos Kuneen Foundation**

There is no ChatGPT, OpenAI, or other external branding in the wallet package metadata.

## Notes
- This wallet is intentionally **not** a generic multi-coin wallet.
- The interface is designed only around **ADK** and the future **ADK DAG** connection path.
- The Node / DAG panel is staged for later live endpoint integration.
