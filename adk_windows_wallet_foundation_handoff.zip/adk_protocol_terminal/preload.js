const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('walletDemo', {
  copy: async (value) => ipcRenderer.invoke('wallet:copy', value)
});
