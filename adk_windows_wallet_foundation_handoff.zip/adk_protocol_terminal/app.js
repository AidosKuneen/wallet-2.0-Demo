const TRYTE_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ9';
const SEED_LENGTH = 81;
const ADDRESS_LENGTHS = [81, 90];

const state = {
  currentSeed: '',
  currentAddress: '',
  nodeUrl: 'https://node.example-adk.local',
  syncReadiness: 87.42,
  transactions: [
    { status: 'Confirmed', hash: 'ADK9BUNDLE9DEMO9A1', direction: 'Received', amount: '+480 ADK', time: '2026-04-09 18:24' },
    { status: 'Pending', hash: 'ADK9BUNDLE9DEMO9A2', direction: 'Sent', amount: '-250 ADK', time: '2026-04-09 14:03' },
    { status: 'Confirmed', hash: 'ADK9BUNDLE9DEMO9A3', direction: 'Received', amount: '+12000 ADK', time: '2026-04-08 09:12' }
  ]
};

function randomTrytes(length) {
  return Array.from({ length }, () => TRYTE_ALPHABET[Math.floor(Math.random() * TRYTE_ALPHABET.length)]).join('');
}

function isValidTrytes(value, allowedLengths) {
  const trimmed = value.trim();
  return allowedLengths.includes(trimmed.length) && /^[A-Z9]+$/.test(trimmed);
}

function isValidSeed(seed) {
  return isValidTrytes(seed, [SEED_LENGTH]);
}

function isValidAdkAddress(address) {
  return isValidTrytes(address, ADDRESS_LENGTHS);
}

function hexToTrytes(hex, targetLength) {
  const clean = hex.replace(/[^0-9a-f]/gi, '').toUpperCase();
  let out = '';
  for (let i = 0; out.length < targetLength; i += 2) {
    const pair = clean.slice(i % clean.length, (i % clean.length) + 2).padEnd(2, '0');
    const num = parseInt(pair, 16);
    out += TRYTE_ALPHABET[num % TRYTE_ALPHABET.length];
  }
  return out.slice(0, targetLength);
}

async function sha256Hex(text) {
  const data = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function deriveDemoAddressFromSeed(seed, index = 0) {
  const digest1 = await sha256Hex(`${seed}:${index}:ADK`);
  const digest2 = await sha256Hex(`${digest1}:${seed}:DAG`);
  const digest3 = await sha256Hex(`${digest2}:CHECKSUM`);
  const base81 = hexToTrytes(digest1 + digest2 + digest3, 81);
  const checksum = hexToTrytes(digest3 + digest2, 9);
  return { base81, withChecksum: base81 + checksum, checksum };
}

function toast(message) {
  const node = document.getElementById('toast');
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => node.classList.remove('show'), 1900);
}

function setAddress(value, checksum = '') {
  state.currentAddress = value;
  document.getElementById('primary-address').textContent = value;
  document.getElementById('receive-address').textContent = value;
  document.getElementById('checksum-view').textContent = checksum || value.slice(-9);
}

function renderTransactions() {
  const list = document.getElementById('tx-list');
  const body = document.getElementById('activity-table-body');
  const items = state.transactions.map((tx) => `
    <div class="tx-item">
      <div class="tx-dot"></div>
      <div>
        <strong>${tx.direction}</strong>
        <div class="tx-meta">${tx.hash} · ${tx.time}</div>
      </div>
      <div><strong>${tx.amount}</strong></div>
    </div>
  `).join('');
  list.innerHTML = items;
  body.innerHTML = state.transactions.map((tx) => `
    <tr>
      <td>${tx.status}</td>
      <td>${tx.hash}</td>
      <td>${tx.direction}</td>
      <td>${tx.amount}</td>
      <td>${tx.time}</td>
    </tr>
  `).join('');
}

function updateSyncMeter(value) {
  state.syncReadiness = value;
  document.getElementById('dag-meter-fill').style.width = `${value}%`;
  document.getElementById('dag-meter-label').textContent = `${value.toFixed(2)}%`;
}

function switchView(viewId) {
  document.querySelectorAll('.nav-item').forEach((btn) => btn.classList.toggle('active', btn.dataset.view === viewId));
  document.querySelectorAll('.view').forEach((section) => section.classList.toggle('active-view', section.id === viewId));
  const active = document.querySelector(`.nav-item[data-view="${viewId}"]`);
  document.getElementById('view-title').textContent = active?.textContent || 'Command Deck';
}

function updateValidationPanel(html, klass = 'neutral') {
  const panel = document.getElementById('validation-panel');
  panel.className = `validation-panel ${klass}`;
  panel.innerHTML = html;
}

function setSeed(seed) {
  state.currentSeed = seed;
  document.getElementById('seed-input').value = seed;
}

async function deriveAndDisplayAddress(index = 0) {
  const seed = document.getElementById('seed-input').value.trim();
  if (!isValidSeed(seed)) {
    document.getElementById('seed-state').textContent = 'Invalid';
    toast('Seed must be exactly 81 ADK trytes');
    return;
  }
  document.getElementById('seed-state').textContent = 'Valid';
  const derived = await deriveDemoAddressFromSeed(seed, index);
  setAddress(derived.withChecksum, derived.checksum);
  toast('ADK demo address derived from seed');
}

document.addEventListener('DOMContentLoaded', async () => {
  renderTransactions();
  document.getElementById('node-url').value = state.nodeUrl;
  updateSyncMeter(state.syncReadiness);

  const startingSeed = randomTrytes(SEED_LENGTH);
  setSeed(startingSeed);
  const derived = await deriveDemoAddressFromSeed(startingSeed, 0);
  setAddress(derived.withChecksum, derived.checksum);
  document.getElementById('seed-state').textContent = 'Valid';

  document.querySelectorAll('.nav-item').forEach((btn) => btn.addEventListener('click', () => switchView(btn.dataset.view)));

  document.querySelectorAll('[data-copy-target]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const target = document.getElementById(btn.dataset.copyTarget);
      await navigator.clipboard.writeText(target.textContent.trim());
      toast('Copied to clipboard');
    });
  });

  document.getElementById('generate-seed-btn').addEventListener('click', () => {
    const seed = randomTrytes(SEED_LENGTH);
    setSeed(seed);
    document.getElementById('seed-state').textContent = 'Valid';
    toast('Fresh ADK seed generated');
  });

  document.getElementById('derive-address-btn').addEventListener('click', () => deriveAndDisplayAddress(0));
  document.getElementById('new-address-btn').addEventListener('click', () => deriveAndDisplayAddress(1));
  document.getElementById('refresh-address').addEventListener('click', () => deriveAndDisplayAddress(2));

  document.getElementById('fill-demo-address').addEventListener('click', async () => {
    const example = await deriveDemoAddressFromSeed(state.currentSeed || randomTrytes(SEED_LENGTH), 7);
    document.getElementById('recipient').value = example.withChecksum;
    toast('ADK sample address inserted');
  });

  document.getElementById('lock-btn').addEventListener('click', () => toast('ADK terminal locked in demo mode'));
  document.getElementById('node-btn').addEventListener('click', () => { switchView('node'); toast('Opened ADK DAG panel'); });

  document.getElementById('save-node-btn').addEventListener('click', () => {
    state.nodeUrl = document.getElementById('node-url').value.trim();
    document.getElementById('connection-state').textContent = 'Saved';
    toast('ADK node endpoint stored locally');
  });

  document.getElementById('test-node-btn').addEventListener('click', () => {
    document.getElementById('connection-state').textContent = 'Simulated';
    document.getElementById('peer-quality').textContent = 'Responsive';
    updateSyncMeter(92.18);
    toast('Simulated ADK node test complete');
  });

  document.getElementById('amount').addEventListener('input', (e) => {
    const value = Number(e.target.value || 0).toFixed(2);
    document.getElementById('preview-amount').textContent = `${value} ADK`;
  });

  document.getElementById('send-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const address = document.getElementById('recipient').value.trim();
    const amount = Number(document.getElementById('amount').value || 0);
    const tag = document.getElementById('tag').value.trim();

    if (!isValidAdkAddress(address)) {
      updateValidationPanel('Invalid ADK address.<br><br>Expected uppercase ADK trytes using A-Z and 9 only, with total length 81 or 90.', 'invalid');
      return;
    }

    updateValidationPanel(
      `Recipient matches ADK-style address rules.<br><br><strong>Amount:</strong> ${amount.toFixed(2)} ADK<br><strong>Tag:</strong> ${tag || 'NONE'}<br><strong>Routing:</strong> Ready for future ADK DAG backend wiring.`,
      'valid'
    );
    toast('ADK transfer payload validated');
  });

  document.getElementById('seed-input').addEventListener('input', (e) => {
    document.getElementById('seed-state').textContent = isValidSeed(e.target.value.trim()) ? 'Valid' : 'Invalid';
  });
});
