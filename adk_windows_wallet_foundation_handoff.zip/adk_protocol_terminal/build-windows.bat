@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"

echo ========================================
echo   ADK Modern Wallet Demo - Windows Build
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js is not installed or not on PATH.
  echo.
  echo Install the LTS version of Node.js from:
  echo https://nodejs.org/
  echo.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo [ERROR] npm is not available on PATH.
  echo.
  echo Reinstall Node.js LTS and make sure npm is included.
  echo.
  pause
  exit /b 1
)

echo [1/3] Installing dependencies...
call npm install
if errorlevel 1 goto :fail

echo.
echo [2/3] Building Windows EXE files...
call npm run dist
if errorlevel 1 goto :fail

echo.
echo [3/3] Done.
echo.
echo Build output should now be in:
echo   %cd%\release
if exist "%cd%\release" start "" "%cd%\release"
echo.
echo You should see files like:
echo   ADK Modern Wallet Demo-Portable-0.1.0.exe
echo   ADK Modern Wallet Demo-Setup-0.1.0.exe
echo.
pause
exit /b 0

:fail
echo.
echo [ERROR] Build failed.
echo Review the messages above for the exact package or tooling issue.
echo.
pause
exit /b 1
